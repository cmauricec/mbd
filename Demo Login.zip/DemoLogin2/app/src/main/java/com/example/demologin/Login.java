package com.example.demologin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;



public class Login extends AppCompatActivity {
    private EditText username;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);


    }
    public void login(View view ) {
        if (username.getText().toString().equals("chris") && password.getText().toString().equals("maur") ||
                (username.getText().toString().equals("josh") && password.getText().toString().equals("mbd"))) {
            //This should take the user to the next view
            startActivity(new Intent(Login.this, Rooms.class));
        } else if (username.getText().toString().equals("chris") && !password.getText().toString().equals("maur")
                || (username.getText().toString().equals("josh") && !password.getText().toString().equals("mbd"))) {
            //Display error that password is incorrect
            //The toast.makeText provides feedback in a small pop-up. It disappears after a short time.
            Toast.makeText(Login.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

        } else if (!username.getText().toString().equals("chris") && !password.getText().toString().equals("maur") ||
                (!username.getText().toString().equals("josh") && !password.getText().toString().equals("mbd"))) {
            //Both username and password are incorrect
            Toast.makeText(Login.this, "Login Error", Toast.LENGTH_SHORT).show();

        } else if (!username.getText().toString().equals("chris") && password.getText().toString().equals("maur") ||
                (!username.getText().toString().equals("josh") && password.getText().toString().equals("mbd"))) {
            //Display error that the username is incorrect
            Toast.makeText(Login.this, "Incorrect Username", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Login.this, "All fields required ", Toast.LENGTH_SHORT).show();
        }
    }

    public void sign_up(View view){
        startActivity(new Intent(Login.this, SignUp.class));;
    }


}
