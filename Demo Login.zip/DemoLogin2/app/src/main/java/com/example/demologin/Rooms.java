package com.example.demologin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class Rooms extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    //This code stills changes between rooms
    //The home button will change back to the room(activity_main) without crashing due to my changes
    public void soft(View view){setContentView(R.layout.soft);}

    public void mobile(View view){setContentView(R.layout.mobile);}

    public void bio(View view){setContentView(R.layout.bio);}

    public void tech(View view){setContentView(R.layout.intech);}

    public void finale(View view){setContentView(R.layout.finals);}

    public void home(View view) { startActivity(new Intent(Rooms.this, Rooms.class));}
    //home button function to return back to rooms

    //The code below crates a menu that will only be seen once user reach the room view
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.menuitem_leaderboard){
            setContentView(R.layout.leaderbrd_layout);
            return true;
        }else if(id == R.id.menuitem_settings){
            return true;
        }else if(id == R.id.menuitem_logout){
            startActivity(new Intent(Rooms.this, Login.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
