package com.example.demologin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);


    }

    public void login(View view ){
        if (username.getText().toString().equals("chris") && password.getText().toString().equals("maur") ||
                (username.getText().toString().equals("josh") && password.getText().toString().equals("mbd"))){
            //This should take the user to the next view
            setContentView(R.layout.activity_main);
        }else if (username.getText().toString().equals("chris") && !password.getText().toString().equals("maur")
                || (username.getText().toString().equals("josh") && !password.getText().toString().equals("mbd"))){
            //Display error that password is incorrect
            //The toast.makeText provides feedback in a small pop-up. It disappears after a short time.
            Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

        }else if (!username.getText().toString().equals("chris") && !password.getText().toString().equals("maur") ||
                (!username.getText().toString().equals("josh") && !password.getText().toString().equals("mbd"))){
            //Both username and password are incorrect
            Toast.makeText(MainActivity.this, "Login Error", Toast.LENGTH_SHORT).show();

        }else if (!username.getText().toString().equals("chris") && password.getText().toString().equals("maur") ||
                (!username.getText().toString().equals("josh") && password.getText().toString().equals("mbd"))){
            //Display error that the username is incorrect
            Toast.makeText(MainActivity.this, "Incorrect Username", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(MainActivity.this, "All fields required ", Toast.LENGTH_SHORT).show();
        }
    }

}